import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

// Minimal table for schema integrity and healthcheck without storing user videos
export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value"),
  updatedAt: timestamp("updated_at").defaultNow(),
});
