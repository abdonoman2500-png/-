"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  BrandCube,
  IconAlert,
  IconBolt,
  IconCheck,
  IconDevice,
  IconDown,
  IconGlobe,
  IconLink,
  IconPaste,
  IconPlay,
  IconPlus,
  IconShield,
  IconSparkles,
  IconSpinner,
  SahhabCloudLogo,
} from "@/components/icons";
import { WelcomeModal } from "@/components/WelcomeModal";
import { normalizeUrlInput } from "@/lib/platforms";

interface ShareNav {
  canShare?: (data: { files: File[] }) => boolean;
  share?: (data: { files?: File[]; title?: string; text?: string; url?: string }) => Promise<void>;
}

export default function Home() {
  const [url, setUrl] = useState("");
  const [buttonText, setButtonText] = useState("حفظ في الجهاز ⬇️");
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusNote, setStatusNote] = useState("");
  const [installEvt, setInstallEvt] = useState<Event | null>(null);
  const [toasts, setToasts] = useState<{ id: number; msg: string; kind: "ok" | "err" }[]>([]);

  // Fast intro modal (Site A style)
  const [showWelcome, setShowWelcome] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  const toast = useCallback((msg: string, kind: "ok" | "err" = "ok", ms = 3200) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), ms);
  }, []);

  /* ---------------- PWA install prompt ---------------- */
  useEffect(() => {
    const h = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e);
    };
    window.addEventListener("beforeinstallprompt", h);
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, []);

  function installApp() {
    const ev = installEvt as (Event & { prompt?: () => void; userChoice?: Promise<{ outcome: string }> }) | null;
    if (ev && ev.prompt) {
      ev.prompt();
      void ev.userChoice?.finally(() => setInstallEvt(null));
    } else {
      const isIOS = typeof navigator !== "undefined" && /iphone|ipad|ipod/i.test(navigator.userAgent);
      toast(
        isIOS
          ? "في سفاري: اضغط زر المشاركة ⎋ ثم «إضافة إلى الشاشة الرئيسية»"
          : "افتح خيارات المتصفح واختر «إضافة إلى الشاشة الرئيسية»",
        "ok",
        5500
      );
    }
  }

  /* ---------------- الدالة البرمجية المطلوبة: حفظ في الجهاز ---------------- */
  const حفظ_في_الجهاز = useCallback(async (customUrl?: string) => {
    const rawTarget = customUrl || url;
    const cleanUrl = normalizeUrlInput(rawTarget);

    if (!cleanUrl) {
      toast("أدخل رابط فيديو صحيح يبدأ بـ http:// أو https://", "err");
      return;
    }

    setUrl(cleanUrl);
    setIsProcessing(true);
    setButtonText("جاري التحميل...");
    setStatusNote("جارٍ جلب الفيديو بأعلى جودة...");

    try {
      // 1. نجيب الفيديو بأعلى جودة تلقائياً من خادم التحميل بصيغة MP4
      const query = new URLSearchParams({
        url: cleanUrl,
        quality: "best",
        title: "abod_video",
      });

      const response = await fetch(`/api/download?${query.toString()}`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const blob = await response.blob();
      const file = new File([blob], "abod_video.mp4", { type: "video/mp4" });

      // 2. إذا كان آيفون / أجهزة تدعم مشاركة الملفات - نفتح قائمة المشاركة لحفظه في الصور مباشرة
      const nav = navigator as unknown as ShareNav;
      if (nav.canShare && nav.canShare({ files: [file] }) && nav.share) {
        try {
          setStatusNote("افتح قائمة المشاركة واختر «حفظ الفيديو» لحفظه بالصور");
          await nav.share({
            files: [file],
            title: "فيديو من عبود",
          });
          toast("تم فتح نافذة المشاركة! اختر «حفظ الفيديو»", "ok", 4000);
        } catch (err: unknown) {
          const e = err as { name?: string };
          if (e?.name !== "AbortError") {
            // تحميل بديل إذا حدث خطأ بمشاركة الملف
            const fileUrl = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = fileUrl;
            a.download = "abod_video.mp4";
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(fileUrl), 6000);
          }
        }
      } else {
        // للكمبيوتر والأندرويد - تحميل عادي
        const fileUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = fileUrl;
        a.download = "abod_video.mp4";
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(fileUrl), 6000);
        toast("تم تنزيل الفيديو إلى جهازك بنجاح!", "ok", 3500);
      }

      setStatusNote("");
    } catch {
      toast("تعذّر تنزيل الفيديو من المصدر، تحقّق من الرابط وحاول مجدداً", "err", 4000);
      setStatusNote("تعذّر التنزيل من هذا الرابط");
    } finally {
      setIsProcessing(false);
      setButtonText("حفظ في الجهاز ⬇️");
    }
  }, [url, toast]);

  /* ---------------- Paste Button ---------------- */
  async function paste() {
    try {
      const t = await navigator.clipboard.readText();
      if (t && t.trim()) {
        const clean = normalizeUrlInput(t) ?? t.trim();
        setUrl(clean);
        toast("تم لصق الرابط من الحافظة!", "ok", 1800);
        inputRef.current?.focus();
      } else {
        toast("الحافظة فارغة — انسخ رابط فيديو أولاً", "err");
      }
    } catch {
      toast("اضغط مطوّلاً في خانة الرابط ثم اختر «لصق»", "ok", 3500);
    }
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    void حفظ_في_الجهاز();
  }

  return (
    <div className="relative min-h-dvh w-full overflow-x-hidden bg-[#02050c] text-white select-none">
      {/* ---------------- Notifications Toast ---------------- */}
      <div className="pointer-events-none fixed inset-x-0 top-3 z-[80] mx-auto flex w-full max-w-[480px] flex-col items-center gap-2 px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`anim-toast pointer-events-auto flex items-center gap-2.5 rounded-full border px-4 py-2 text-[13px] font-semibold shadow-2xl backdrop-blur-xl ${
              t.kind === "err"
                ? "border-red-500/40 bg-[#1e0a0d]/95 text-red-200"
                : "border-cyan-400/60 bg-[#071329]/95 text-white shadow-[0_0_30px_rgba(0,229,255,0.4)]"
            }`}
          >
            {t.kind === "err" ? (
              <IconAlert size={16} className="shrink-0 text-red-400" />
            ) : (
              <IconSparkles size={16} className="shrink-0 text-cyan-300" />
            )}
            <span>{t.msg}</span>
          </div>
        ))}
      </div>

      {/* ========================================================================= */}
      {/* 100% EXACT SCREENSHOT REPLICA HERO INTERFACE                              */}
      {/* ========================================================================= */}
      <section className="relative min-h-screen w-full flex flex-col justify-between overflow-hidden">
        {/* Exact Man Portrait Photo Background from the user's screenshot */}
        <div className="absolute inset-0 pointer-events-none z-0">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-90 scale-100 filter brightness-100 contrast-105"
            style={{ backgroundImage: "url('/images/murad-man-bg.jpg')" }}
          />

          {/* Dark moody studio vignette matching screenshot */}
          <div className="absolute inset-0 bg-radial-[circle_at_50%_35%] from-transparent via-[#02050c]/40 to-[#02050c]/90" />
          <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[#02050c]/80 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 h-36 bg-gradient-to-t from-[#02050c] via-[#02050c]/85 to-transparent" />

          {/* Volumetric Neon Ambient Glow in Center */}
          <div className="absolute top-[32%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[450px] bg-gradient-to-tr from-cyan-500/30 via-blue-600/25 to-purple-600/30 rounded-full blur-[130px]" />
        </div>

        {/* ---------------- Top Header (Matching Screenshot) ---------------- */}
        <header className="relative z-30 mx-auto w-full max-w-[460px] px-4 pt-3 flex items-center justify-between">
          {/* Right: Cloud Logo + Name */}
          <div className="flex items-center gap-1.5">
            <SahhabCloudLogo size={28} />
            <span className="text-[17px] font-black tracking-wider text-white">عبود</span>
          </div>

          {/* Middle: Video intro trigger */}
          <button
            onClick={() => setShowWelcome(true)}
            className="flex items-center gap-1.5 rounded-full border border-white/20 bg-black/60 px-3.5 py-1 text-[11px] font-bold text-slate-200 backdrop-blur-md hover:bg-black/80 transition cursor-pointer"
          >
            <IconPlay size={10} className="text-cyan-400 fill-cyan-400" />
            <span>فيديو البداية الترحيبي</span>
          </button>

          {/* Left: Install App Pill Button */}
          <button
            onClick={installApp}
            className="flex items-center gap-1 rounded-full border border-cyan-400/50 bg-[#071329]/90 px-3 py-1 text-[11px] font-black text-cyan-300 transition hover:bg-cyan-500/25 active:scale-95 shadow-[0_0_15px_rgba(0,229,255,0.35)] cursor-pointer"
          >
            <IconPlus size={12} />
            <span>تثبيت التطبيق</span>
          </button>
        </header>

        {/* ---------------- Central Hero Stage ---------------- */}
        <div className="relative z-20 mx-auto w-full max-w-[440px] flex flex-col items-center px-4 pt-4 my-auto">
          {/* 1. Exact Glowing Neon Cloud with Down Arrow */}
          <div className="anim-neon-pulse mb-2.5 flex flex-col items-center drop-shadow-[0_0_35px_rgba(0,229,255,0.95)]">
            <SahhabCloudLogo size={92} />
          </div>

          {/* 2. Main Title in Exact Glowing Cyber Typography */}
          <div className="text-center mb-6">
            <h1 className="text-[54px] font-black tracking-tight gradient-abboud-title leading-none drop-shadow-[0_0_40px_rgba(0,229,255,0.95)]">
              عبود
            </h1>
            <p className="mt-2 text-[17px] font-bold text-white tracking-wide drop-shadow-[0_2px_12px_rgba(0,0,0,0.9)]">
              حمّل أي فيديو من أي تطبيق
            </p>
          </div>

          {/* 3. The Exact Cyber Search Bar ---------------- */}
          <div className="relative z-30 w-full px-1">
            {/* Interactive touch spark / lens flare glow */}
            <div className="pointer-events-none absolute -top-3 right-6 h-14 w-14 rounded-full bg-cyan-400/50 blur-xl anim-flare-pulse" />

            <form
              onSubmit={handleSubmit}
              className="exact-search-capsule relative flex items-center rounded-full p-2 transition-all duration-300"
            >
              {/* Right Button inside capsule: Link chain icon + "+" badge (Paste from clipboard) */}
              <button
                type="button"
                onClick={paste}
                title="لصق الرابط من الحافظة"
                className="exact-link-circle relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-cyan-200 transition hover:scale-105 active:scale-95 cursor-pointer"
              >
                <IconLink size={19} className="stroke-[2.5]" />
                <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-cyan-400 text-[9px] font-black text-black">
                  +
                </span>
              </button>

              {/* Central Text Input (id="video-link" matching the script) */}
              <input
                id="video-link"
                ref={inputRef}
                dir="rtl"
                type="text"
                inputMode="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="أدخل رابط الفيديو هنا..."
                className="min-w-0 flex-1 bg-transparent px-3 text-right text-[14.5px] font-semibold text-white placeholder:text-slate-400 outline-none"
              />

              {/* Clear button if text exists */}
              {url ? (
                <button
                  type="button"
                  onClick={() => setUrl("")}
                  className="mx-1 h-6 w-6 rounded-full bg-white/10 text-slate-300 hover:text-white flex items-center justify-center text-xs font-bold cursor-pointer"
                >
                  ×
                </button>
              ) : null}

              {/* The Download Button (.download-btn matching the script) */}
              <button
                type="submit"
                disabled={isProcessing}
                className="download-btn exact-action-btn flex shrink-0 items-center gap-1.5 rounded-full px-5 py-2.5 text-[14px] font-black text-white transition-all hover:brightness-110 active:scale-95 cursor-pointer shadow-[0_0_20px_rgba(0,229,255,0.5)] disabled:opacity-70"
              >
                {isProcessing ? (
                  <IconSpinner size={16} className="text-white" />
                ) : (
                  <IconDown size={17} className="stroke-[3]" />
                )}
                <span>{buttonText}</span>
              </button>
            </form>
          </div>

          {/* Quick Helper Note during processing */}
          {statusNote && (
            <div className="anim-rise mt-3 w-full rounded-2xl border border-cyan-400/50 bg-[#071329]/90 px-4 py-2 text-center text-[12.5px] font-bold text-cyan-200 backdrop-blur-md shadow-[0_0_20px_rgba(0,229,255,0.25)]">
              {statusNote}
            </div>
          )}

          {/* 4. Exact 7 Glossy Round App Icons underneath Search Bar */}
          <div className="mt-5 w-full flex items-center justify-between px-1">
            <BrandCube brand="telegram" size={44} />
            <BrandCube brand="facebook" size={44} />
            <BrandCube brand="x" size={44} />
            <BrandCube brand="snapchat" size={44} />
            <BrandCube brand="instagram" size={44} />
            <BrandCube brand="youtube" size={44} />
            <BrandCube brand="tiktok" size={44} />
          </div>

          {/* 5. Exact 2x2 Dark Features Box from Screenshot */}
          <div className="mt-5 w-full">
            <div className="exact-features-card rounded-[22px] p-3 text-center">
              {/* Row 1 */}
              <div className="grid grid-cols-2 pb-2.5 border-b border-white/10">
                <div className="flex items-center justify-center gap-2 border-l border-white/10 pl-2">
                  <span className="text-cyan-400">
                    <IconBolt size={18} />
                  </span>
                  <span className="text-[13px] font-black text-white">سريع وأمن</span>
                </div>
                <div className="flex items-center justify-center gap-2 pr-2">
                  <span className="text-blue-400">
                    <IconShield size={18} />
                  </span>
                  <span className="text-[13px] font-black text-white">بدون برامج</span>
                </div>
              </div>

              {/* Row 2 */}
              <div className="grid grid-cols-2 pt-2.5">
                <div className="flex items-center justify-center gap-2 border-l border-white/10 pl-2">
                  <span className="text-purple-400">
                    <IconDevice size={18} />
                  </span>
                  <span className="text-[12px] font-black text-white">يعمل على الجوال والكمبيوتر</span>
                </div>
                <div className="flex items-center justify-center gap-2 pr-2">
                  <span className="text-pink-400">
                    <IconGlobe size={18} />
                  </span>
                  <span className="text-[12px] font-black text-white">جميع المواقع المدعومة</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ---------------- Clean Simple Footer ---------------- */}
        <div className="relative z-30 pb-4 pt-2 flex flex-col items-center">
          <p className="text-[12px] font-bold text-slate-400 flex items-center gap-1.5">
            <IconCheck size={14} className="text-cyan-400" />
            <span>حفظ تلقائي بأعلى جودة بصيغة MP4 في استوديو الصور مباشرة 🖼️</span>
          </p>
        </div>
      </section>

      {/* Optional Welcome Intro Screen (when requested by user) */}
      {showWelcome && (
        <WelcomeModal
          onEnter={() => {
            setShowWelcome(false);
            inputRef.current?.focus();
          }}
        />
      )}
    </div>
  );
}
