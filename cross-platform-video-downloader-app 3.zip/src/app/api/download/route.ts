import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { Readable } from "node:stream";
import { detectPlatform, isDirectMediaUrl } from "@/lib/engine";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

function ytdlpBin(): string {
  const candidates = [
    process.env.YTDLP_BIN,
    path.join(process.cwd(), "bin", "yt-dlp"),
    "/usr/local/bin/yt-dlp",
    "/usr/bin/yt-dlp",
  ].filter(Boolean) as string[];

  for (const c of candidates) {
    if (!c.includes("/")) return c;
    if (fs.existsSync(c)) {
      try {
        fs.accessSync(c, fs.constants.X_OK);
      } catch {
        try {
          fs.chmodSync(c, 0o755);
        } catch {
          continue;
        }
      }
      return c;
    }
  }
  return "yt-dlp";
}

function sanitizeFilename(name: string): string {
  const clean = name
    .replace(/[/\\?%*:|"<>]/g, "_")
    .replace(/\s+/g, " ")
    .trim();
  return clean ? clean.slice(0, 100) : "video";
}

function cleanOldTempFiles() {
  const tempDir = os.tmpdir();
  try {
    const now = Date.now();
    for (const f of fs.readdirSync(tempDir)) {
      if (f.startsWith("sahhab_")) {
        const full = path.join(tempDir, f);
        try {
          const st = fs.statSync(full);
          if (now - st.mtimeMs > 60000) fs.unlinkSync(full);
        } catch {
          /* ignore */
        }
      }
    }
  } catch {
    /* ignore */
  }
}

export async function GET(req: Request) {
  cleanOldTempFiles();
  const { searchParams } = new URL(req.url);
  const rawUrl = searchParams.get("url")?.trim();
  const quality = searchParams.get("quality")?.trim() || "best";
  const userTitle = searchParams.get("title")?.trim();

  if (!rawUrl) {
    return new Response("الرابط مفقود", { status: 400 });
  }

  // 1) Direct media link (mp4, webm, etc.)
  if (isDirectMediaUrl(rawUrl)) {
    try {
      const upstream = await fetch(rawUrl, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        },
        signal: AbortSignal.timeout(120000),
      });

      if (!upstream.ok || !upstream.body) {
        return new Response("فشل الاتصال برابط الفيديو المباشر", { status: 502 });
      }

      const safeName = sanitizeFilename(userTitle || "video");
      const filename = `${safeName}.mp4`;
      const encodedName = encodeURIComponent(filename);

      const headers = new Headers();
      headers.set("Content-Type", upstream.headers.get("content-type") || "video/mp4");
      headers.set("Content-Disposition", `attachment; filename="${filename}"; filename*=UTF-8''${encodedName}`);
      const cl = upstream.headers.get("content-length");
      if (cl) headers.set("Content-Length", cl);

      return new Response(upstream.body, { status: 200, headers });
    } catch {
      return new Response("تعذّر تنزيل الرابط المباشر", { status: 500 });
    }
  }

  // 2) Platform video via yt-dlp -> temporary file in /tmp/ deleted immediately after serving
  const tempId = randomUUID();
  const tempDir = os.tmpdir();
  const tempPattern = path.join(tempDir, `sahhab_${tempId}.%(ext)s`);

  let formatArg = "best[ext=mp4]/best";
  if (quality !== "best") {
    const h = parseInt(quality, 10);
    if (!Number.isNaN(h) && h > 0) {
      formatArg = `best[height<=?${h}][ext=mp4]/best[height<=?${h}]/best`;
    }
  }

  const bin = ytdlpBin();
  const args = [
    "--user-agent",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "-f",
    formatArg,
    "--no-playlist",
    "--no-part",
    "--no-warnings",
    "--socket-timeout",
    "35",
    "--retries",
    "2",
    "-o",
    tempPattern,
    rawUrl,
  ];

  try {
    await new Promise<void>((resolve, reject) => {
      const p = spawn(bin, args, { stdio: ["ignore", "pipe", "pipe"] });
      let err = "";
      const timer = setTimeout(() => {
        p.kill("SIGKILL");
        reject(new Error("انتهت مهلة تحميل الفيديو من المصدر."));
      }, 180000);

      p.stderr.on("data", (d) => (err += d.toString()));
      p.on("error", (e) => {
        clearTimeout(timer);
        reject(e);
      });
      p.on("close", (code) => {
        clearTimeout(timer);
        if (code === 0) resolve();
        else reject(new Error(err || "فشل تحميل الفيديو من المصدر."));
      });
    });

    // Find the produced file in tempDir
    const files = fs.readdirSync(tempDir);
    const producedName = files.find((f) => f.startsWith(`sahhab_${tempId}`));
    if (!producedName) {
      return new Response("تعذّر إنشاء ملف الفيديو", { status: 500 });
    }

    const producedPath = path.join(tempDir, producedName);
    const stat = fs.statSync(producedPath);
    const ext = path.extname(producedPath).replace(".", "").toLowerCase() || "mp4";
    const safeName = sanitizeFilename(userTitle || "video");
    const filename = `${safeName}.${ext}`;
    const encodedName = encodeURIComponent(filename);

    const stream = fs.createReadStream(producedPath);
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      try {
        if (fs.existsSync(producedPath)) fs.unlinkSync(producedPath);
      } catch {
        /* noop */
      }
    };
    stream.on("end", cleanup);
    stream.on("close", cleanup);
    stream.on("error", cleanup);
    req.signal.addEventListener("abort", cleanup);
    // Safety fallback: ensure cleanup within 5 minutes even if connection stalled
    setTimeout(cleanup, 5 * 60 * 1000);

    const webStream = Readable.toWeb(stream as unknown as Readable) as ReadableStream;

    const headers = new Headers();
    headers.set("Content-Type", ext === "webm" ? "video/webm" : ext === "mov" ? "video/quicktime" : "video/mp4");
    headers.set("Content-Disposition", `attachment; filename="${filename}"; filename*=UTF-8''${encodedName}`);
    headers.set("Content-Length", String(stat.size));
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");

    return new Response(webStream, { status: 200, headers });
  } catch (e) {
    // Clean up any remnants
    try {
      const files = fs.readdirSync(tempDir);
      for (const f of files) {
        if (f.startsWith(`sahhab_${tempId}`)) {
          fs.unlinkSync(path.join(tempDir, f));
        }
      }
    } catch {
      /* ignore */
    }
    const msg = e instanceof Error ? e.message : "حدث خطأ أثناء تحميل الفيديو.";
    return new Response(msg, { status: 502, headers: { "Content-Type": "text/plain; charset=utf-8" } });
  }
}
