import { extractVideo, arError } from "@/lib/engine";
import { normalizeUrlInput } from "@/lib/platforms";

export const dynamic = "force-dynamic";
export const maxDuration = 90;

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const rawUrl = typeof body?.url === "string" ? body.url : "";
    if (!rawUrl.trim()) return Response.json({ error: "أدخل رابط الفيديو أولاً." }, { status: 400 });

    const url = normalizeUrlInput(rawUrl);
    if (!url) {
      return Response.json(
        { error: "لم أجد رابطاً صحيحاً داخل النص المُلصق — الصق رابط الفيديو كاملاً." },
        { status: 400 }
      );
    }

    const result = await extractVideo(url);
    return Response.json(result);
  } catch (e) {
    console.error("[extract] failed:", e);
    const msg = e instanceof Error ? arError(e.message) : "حدث خطأ غير متوقع.";
    return Response.json({ error: msg }, { status: 422 });
  }
}
