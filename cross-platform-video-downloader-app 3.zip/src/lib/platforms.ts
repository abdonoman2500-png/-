export interface PlatformInfo {
  key: string;
  name: string;
  color: string; // hex
  example?: string;
}

export const PLATFORMS: Record<string, PlatformInfo> = {
  youtube: { key: "youtube", name: "يوتيوب", color: "#FF4B4B", example: "https://youtube.com/watch?v=…" },
  tiktok: { key: "tiktok", name: "تيك توك", color: "#2EE6C8", example: "https://tiktok.com/@user/video/…" },
  instagram: { key: "instagram", name: "انستجرام", color: "#F771B0", example: "https://instagram.com/reel/…" },
  x: { key: "x", name: "إكس (تويتر)", color: "#7DD3FC", example: "https://x.com/user/status/…" },
  facebook: { key: "facebook", name: "فيسبوك", color: "#5B8DEF", example: "https://facebook.com/watch/…" },
  twitch: { key: "twitch", name: "تويتش", color: "#B48CFF", example: "https://twitch.tv/…" },
  vimeo: { key: "vimeo", name: "فيميو", color: "#4FC3F7", example: "https://vimeo.com/…" },
  dailymotion: { key: "dailymotion", name: "دي موشن", color: "#F5A524", example: "https://dailymotion.com/…" },
  snapchat: { key: "snapchat", name: "سناب شات", color: "#FFE04D", example: "https://snapchat.com/…" },
  direct: { key: "direct", name: "رابط مباشر", color: "#3DDC97", example: "https://site.com/video.mp4" },
  generic: { key: "generic", name: "موقع آخر", color: "#93A0B4", example: "https://…" },
};

export function platformInfo(key: string): PlatformInfo {
  return PLATFORMS[key] ?? PLATFORMS.generic;
}

export function detectClientPlatform(url: string): string {
  const u = url.toLowerCase();
  if (/(^|\.)youtube\.com|youtu\.be|youtube-nocookie/.test(u)) return "youtube";
  if (/(^|\.)tiktok\.com|vm\.tiktok/.test(u)) return "tiktok";
  if (/(^|\.)instagram\.com|instagr\.am/.test(u)) return "instagram";
  if (/(^|\.)x\.com|(^|\.)twitter\.com/.test(u)) return "x";
  if (/(^|\.)facebook\.com|fb\.watch|fb\.com/.test(u)) return "facebook";
  if (/(^|\.)twitch\.tv/.test(u)) return "twitch";
  if (/(^|\.)vimeo\.com/.test(u)) return "vimeo";
  if (/(^|\.)dailymotion\.com/.test(u)) return "dailymotion";
  if (/(^|\.)snapchat\.com/.test(u)) return "snapchat";
  if (/\.(mp4|webm|mov|m4v|mkv|avi)(\?|$)/.test(u)) return "direct";
  return "generic";
}

export function isValidUrl(s: string): boolean {
  try {
    const u = new URL(s.trim());
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

/**
 * Mobile share sheets often copy explanatory text around the actual URL,
 * and sometimes omit the protocol. Extract and normalize the first usable
 * web URL instead of rejecting the whole pasted value.
 */
export function normalizeUrlInput(input: string): string | null {
  const text = input.replace(/[\u200b-\u200d\ufeff]/g, " ").trim();
  if (!text) return null;

  const match =
    text.match(/https?:\/\/[^\s<>"'，。؛]+/i) ??
    text.match(/(?:www\.)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s<>"'，。؛]*)?/i);
  if (!match) return null;

  let candidate = match[0]
    .replace(/[)\]}>»”’]+$/g, "")
    .replace(/[.,!?؟،؛:]+$/g, "");
  if (!/^https?:\/\//i.test(candidate)) candidate = `https://${candidate}`;

  try {
    const parsed = new URL(candidate);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
    if (!parsed.hostname.includes(".")) return null;
    return parsed.toString();
  } catch {
    return null;
  }
}

export function formatDuration(sec?: number): string {
  if (!sec || sec <= 0) return "";
  const s = Math.round(sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
  return `${m}:${String(r).padStart(2, "0")}`;
}

export function formatBytes(n?: number | null): string {
  if (!n || !isFinite(n) || n <= 0) return "";
  const units = ["ب", "ك.ب", "م.ب", "ج.ب"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${units[i]}`;
}
