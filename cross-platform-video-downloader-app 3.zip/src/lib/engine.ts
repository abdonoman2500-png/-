import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

/* ------------------------------------------------------------------ */
/* Constants & helpers                                                 */
/* ------------------------------------------------------------------ */

const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

export function ytdlpBin(): string {
  const candidates = [
    process.env.YTDLP_BIN,
    path.join(process.cwd(), "bin", "yt-dlp"),
    "/usr/local/bin/yt-dlp",
    "/usr/bin/yt-dlp",
  ].filter(Boolean) as string[];

  for (const candidate of candidates) {
    if (!candidate.includes("/")) return candidate;
    if (!fs.existsSync(candidate)) continue;
    try {
      fs.accessSync(candidate, fs.constants.X_OK);
    } catch {
      try {
        fs.chmodSync(candidate, 0o755);
      } catch {
        continue;
      }
    }
    return candidate;
  }

  return "yt-dlp";
}

export function detectPlatform(url: string): string {
  const u = url.toLowerCase();
  if (/(^|\.)youtube\.com|youtu\.be|youtube-nocookie/.test(u)) return "youtube";
  if (/(^|\.)tiktok\.com|vm\.tiktok/.test(u)) return "tiktok";
  if (/(^|\.)instagram\.com|instagr\.am/.test(u)) return "instagram";
  if (/(^|\.)x\.com|(^|\.)twitter\.com/.test(u)) return "x";
  if (/(^|\.)facebook\.com|fb\.watch|fb\.com/.test(u)) return "facebook";
  if (/(^|\.)twitch\.tv/.test(u)) return "twitch";
  if (/(^|\.)vimeo\.com/.test(u)) return "vimeo";
  if (/(^|\.)dailymotion\.com/.test(u)) return "dailymotion";
  if (/(^|\.)snapchat\.com/.test(u)) return "snapchat";
  if (/\.(mp4|webm|mov|m4v|mkv|avi|ogv|ogg)(\?|$)/.test(u)) return "direct";
  return "generic";
}

export function isDirectMediaUrl(url: string): boolean {
  return detectPlatform(url) === "direct";
}

export interface QualityOption {
  id: string;
  label: string;
  size?: number;
}

export interface ExtractResult {
  title: string;
  thumbnail?: string | null;
  duration?: number;
  uploader?: string;
  platform: string;
  direct: boolean;
  qualities: QualityOption[];
}

const ERROR_MAP: Array<[RegExp, string]> = [
  [/Sign in to confirm|not a bot/i, "المصدر يطلب تحققًا آليًا (Bot check) من هذا الخادم. الروابط المباشرة وبعض المصادر الأخرى تعمل فوراً."],
  [/Video not available|isn't available|private video|Private video/i, "هذا الفيديو غير متاح، محذوف، أو خاص."],
  [/HTTP Error 404|not found|no longer exists/i, "الرابط غير موجود (404)."],
  [/HTTP Error 403|forbidden|blocked/i, "الموقع منع الوصول من هذا الخادم (403)."],
  [/log ?in|login required|authentication|cookies/i, "هذا المصدر يتطلب تسجيل دخول للوصول."],
  [/Unable to download webpage|timed out|timed-out|Connection|network/i, "تعذّر الاتصال بالمصدر — تحقّق من الرابط وحاول مجدداً."],
  [/not a valid URL|Unsupported URL/i, "الرابط غير صالح أو الموقع غير مدعوم."],
  [/Requested format is not available|no video/i, "الجودة المطلوبة غير متوفرة لهذا الفيديو."],
  [/Too many requests|rate limit/i, "طلبات كثيرة — انتظر دقيقة ثم حاول مجدداً."],
  [/Unexpected response/i, "الموقع ردّ بشكل غير متوقع. جرّب رابطاً آخر."],
];

export function arError(raw: string): string {
  const line = raw
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .find((l) => l.includes("ERROR:")) ?? raw.trim();
  const clean = line.replace(/^ERROR:\s*(\[[\w-]+\]\s*)?/, "");
  for (const [re, msg] of ERROR_MAP) {
    if (re.test(clean)) return msg;
  }
  return clean.length > 140 ? clean.slice(0, 140) + "…" : clean || "حدث خطأ غير معروف أثناء قراءة الفيديو.";
}

/* ------------------------------------------------------------------ */
/* Extraction                                                          */
/* ------------------------------------------------------------------ */

interface YtFormat {
  format_id?: string;
  ext?: string;
  vcodec?: string;
  acodec?: string;
  height?: number;
  filesize?: number;
  filesize_approx?: number;
  tbr?: number;
  protocol?: string;
  format_note?: string;
}

function pickFormatSize(formats: YtFormat[], height: number): number | undefined {
  let best: number | undefined;
  for (const f of formats) {
    if (f.height === height && (f.filesize || f.filesize_approx)) {
      const s = f.filesize || f.filesize_approx!;
      if (best === undefined || s < best) best = s;
    }
  }
  return best;
}

function buildQualities(formats: YtFormat[]): QualityOption[] {
  const heights = new Set<number>();
  for (const f of formats) {
    if (f.vcodec && f.vcodec !== "none" && f.height) heights.add(f.height);
  }
  const sorted = [...heights].sort((a, b) => b - a);
  const opts: QualityOption[] = [];
  if (sorted.length === 0) {
    opts.push({ id: "best", label: "أفضل جودة" });
    return opts;
  }
  opts.push({ id: "best", label: `الأعلى (${sorted[0]}p)`, size: pickFormatSize(formats, sorted[0]) });
  for (const h of [1080, 720, 480, 360, 240]) {
    if (heights.has(h)) opts.push({ id: String(h), label: `${h}p`, size: pickFormatSize(formats, h) });
  }
  for (const h of sorted) {
    if (!opts.some((o) => o.id === String(h))) {
      opts.push({ id: String(h), label: `${h}p`, size: pickFormatSize(formats, h) });
    }
  }
  return opts;
}

async function directMeta(url: string): Promise<ExtractResult> {
  const platform = detectPlatform(url);
  let size: number | undefined;
  try {
    const res = await fetch(url, {
      method: "GET",
      headers: { "User-Agent": BROWSER_UA, Range: "bytes=0-0" },
      redirect: "follow",
      signal: AbortSignal.timeout(20000),
    });
    const cr = res.headers.get("content-range");
    if (cr) {
      const m = cr.match(/\/(\d+)\s*$/);
      if (m) size = Number(m[1]);
    }
    if (!size) size = Number(res.headers.get("content-length")) || undefined;
  } catch {
    /* size optional */
  }
  let title = "فيديو مباشر";
  try {
    const u = new URL(url);
    const base = decodeURIComponent(u.pathname.split("/").filter(Boolean).pop() || "");
    if (base) title = base.replace(/\.[a-z0-9]{2,5}$/i, "").replace(/[-_]+/g, " ");
  } catch {
    /* ignore */
  }
  return {
    title,
    thumbnail: null,
    duration: undefined,
    platform,
    direct: true,
    qualities: [{ id: "best", label: "جودة المصدر", size }],
  };
}

export async function extractVideo(url: string): Promise<ExtractResult> {
  if (isDirectMediaUrl(url)) return directMeta(url);

  const bin = ytdlpBin();
  const info = await new Promise<string>((resolve, reject) => {
    const p = spawn(
      bin,
      ["--user-agent", BROWSER_UA, "-J", "--no-playlist", "--no-warnings", "--socket-timeout", "25", url],
      { stdio: ["ignore", "pipe", "pipe"] }
    );
    let out = "";
    let err = "";
    let settled = false;
    const t = setTimeout(() => {
      if (!settled) {
        settled = true;
        p.kill("SIGKILL");
        reject(new Error(arError(err || "انتهت مهلة الاتصال بالمصدر.")));
      }
    }, 60000);

    p.stdout.on("data", (d) => (out += d.toString()));
    p.stderr.on("data", (d) => (err += d.toString()));
    p.on("error", (e) => {
      if (settled) return;
      settled = true;
      clearTimeout(t);
      reject(new Error(`تعذّر تشغيل محرك التحميل: ${e.message}`));
    });
    p.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(t);
      if (code === 0 && out.trim()) resolve(out);
      else reject(new Error(arError(err || out || "فشل التحليل.")));
    });
  });

  const data = JSON.parse(info) as {
    title?: string;
    thumbnail?: string | null;
    duration?: number | null;
    uploader?: string;
    channel?: string;
    formats?: YtFormat[];
  };

  return {
    title: data.title || "فيديو",
    thumbnail: data.thumbnail || null,
    duration: data.duration ?? undefined,
    uploader: data.uploader || data.channel,
    platform: detectPlatform(url),
    direct: false,
    qualities: buildQualities(data.formats ?? []),
  };
}
