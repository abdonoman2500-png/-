"use client";

import { useEffect, useRef, useState } from "react";
import { BrandCube, SahhabCloudLogo } from "@/components/icons";

interface IntroVideoProps {
  onComplete: () => void;
  onSkip: () => void;
}

// 3 seconds total — ultra short, punchy & clean!
const SHORT_DURATION = 3;

export function IntroCinematicVideo({ onComplete, onSkip }: IntroVideoProps) {
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState<1 | 2>(1); // 1: hands open laptop, 2: apps burst
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const startTime = Date.now();
    const durationMs = SHORT_DURATION * 1000;

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, (elapsed / durationMs) * 100);
      setProgress(pct);

      if (elapsed > 1100 && stage === 1) {
        setStage(2);
      }

      if (elapsed >= durationMs) {
        clearInterval(interval);
        onComplete();
      }
    }, 40);

    return () => clearInterval(interval);
  }, [stage, onComplete]);

  // Fast playback rate
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = 1.6;
      videoRef.current.play().catch(() => {});
    }
  }, []);

  return (
    <div
      onClick={onSkip}
      className="fixed inset-0 z-[120] flex items-center justify-center bg-[#02050c] text-white overflow-hidden select-none cursor-pointer"
    >
      {/* Background opening laptop clip */}
      <div className="absolute inset-0">
        <video
          ref={videoRef}
          src="/videos/open-laptop.mp4"
          muted
          playsInline
          autoPlay
          className="h-full w-full object-cover filter brightness-75 contrast-125"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#02050c] via-black/40 to-[#02050c]/80" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,229,255,0.35)_0%,transparent_70%)]" />
      </div>

      {/* Floating App Icons Bursting in Center (Without distracting text!) */}
      <div className="relative z-10 flex flex-col items-center justify-center p-4 pointer-events-none">
        {/* Glowing Central Cloud Logo */}
        <div className="transition-all duration-500 transform scale-110 drop-shadow-[0_0_40px_rgba(0,229,255,0.95)] mb-4">
          <SahhabCloudLogo size={96} className="anim-neon-pulse" />
        </div>

        {/* Floating 3D App Icons Row (tiktok, youtube, instagram, snapchat, x, facebook, telegram) */}
        <div
          className={`flex items-center justify-center gap-3 transition-all duration-500 transform ${
            stage === 2
              ? "opacity-100 scale-105 translate-y-0 drop-shadow-[0_0_30px_rgba(0,229,255,0.6)]"
              : "opacity-40 scale-75 translate-y-4"
          }`}
        >
          <BrandCube brand="tiktok" size={46} className="animate-bounce [animation-delay:0ms]" />
          <BrandCube brand="youtube" size={46} className="animate-bounce [animation-delay:100ms]" />
          <BrandCube brand="instagram" size={46} className="animate-bounce [animation-delay:200ms]" />
          <BrandCube brand="snapchat" size={46} className="animate-bounce [animation-delay:300ms]" />
          <BrandCube brand="x" size={46} className="animate-bounce [animation-delay:400ms]" />
          <BrandCube brand="facebook" size={46} className="animate-bounce [animation-delay:500ms]" />
          <BrandCube brand="telegram" size={46} className="animate-bounce [animation-delay:600ms]" />
        </div>
      </div>

      {/* Top Direct Skip Pill */}
      <div className="absolute top-4 right-4 z-50 pointer-events-auto">
        <button
          onClick={onSkip}
          className="flex items-center gap-1.5 rounded-full border border-cyan-400/50 bg-black/60 px-4 py-1.5 text-[12px] font-black text-cyan-300 backdrop-blur-md transition hover:bg-cyan-500/20 active:scale-95 cursor-pointer shadow-[0_0_20px_rgba(0,229,255,0.4)]"
        >
          <span>تخطي</span>
          <span>⤹</span>
        </button>
      </div>

      {/* Bottom 3-Second Fast Progress Bar */}
      <div className="absolute bottom-0 inset-x-0 h-1.5 bg-slate-900/80 z-50">
        <div
          className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 shadow-[0_0_15px_rgba(0,229,255,1)] transition-all duration-75"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}
